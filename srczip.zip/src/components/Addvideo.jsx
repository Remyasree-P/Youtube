const Addvideo=()=>{
    return (
        <div className="addvideo">
            <form action="">
                <label htmlFor="">
                    Title: <input type="text" placeholder="enter the video Name" />
                </label>
                <br />
                <label htmlFor="">
                    description: <textarea placeholder="Enter the discription about the video"/>
                </label>
                <br />
                <label htmlFor="">
                    VideoUrl : <input required type="text" placeholder="enter the video details"/>
                </label>
                <br />
                <label htmlFor="">
                    Likes : <input required type="number" />
                </label>
                <br />
                <button>Add video</button>
            </form>
        </div>
    )
}
export default Addvideo;