const AdminView=()=>{
    return(
        <div className="adminview">
            <h1>AdminView</h1>
        </div>
    )
}
export default AdminView;